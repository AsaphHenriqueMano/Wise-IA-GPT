
import React, { useState } from 'react';
export default function AgentEditor({ onSave }) {
  const [text, setText] = useState(JSON.stringify({
    id: `agent-${Date.now()}`,
    name: 'Novo Agente',
    description: 'Descrição do agente',
    nodes: [
      { id: 'input', type: 'input' },
      { id: 'model', type: 'model', model: 'gpt-4-turbo', temperature: 0.2, promptTemplate: 'Resuma: {{user_input}}' },
      { id: 'output', type: 'output' }
    ],
    connections: [['input','model'],['model','output']]
  }, null, 2));

  function save() {
    try {
      const obj = JSON.parse(text);
      onSave(obj);
      alert('Agente salvo!');
    } catch (e) {
      alert('JSON inválido: ' + e.message);
    }
  }

  return (
    <div className="p-4 bg-white rounded shadow">
      <h2 className="font-semibold">Editor JSON</h2>
      <textarea rows={18} className="w-full border p-2 mt-2" value={text} onChange={e => setText(e.target.value)} />
      <button className="mt-2 px-3 py-1 bg-blue-600 text-white rounded" onClick={save}>Salvar Agente</button>
    </div>
  );
}
