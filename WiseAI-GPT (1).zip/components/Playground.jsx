
import React, { useState, useRef, useEffect } from 'react';
export default function Playground({ agent }) {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const evtSourceRef = useRef(null);

  useEffect(() => () => { if (evtSourceRef.current) evtSourceRef.current.close(); }, []);

  function run() {
    if (!agent) { alert('Salve um agente primeiro.'); return; }
    setOutput('');
    const url = `/api/stream?agentId=${agent.id}&input=${encodeURIComponent(input)}`;
    const es = new EventSource(url);
    evtSourceRef.current = es;

    es.onmessage = (ev) => {
      try {
        const data = JSON.parse(ev.data);
        if (data.type === 'token') setOutput(prev => prev + data.token);
        else if (data.type === 'done') es.close();
      } catch (e) { console.error(e); }
    };

    es.onerror = () => es.close();
  }

  return (
    <div className="p-4 bg-white rounded shadow">
      <h2 className="font-semibold">Playground</h2>
      <textarea rows={6} className="w-full border p-2 mt-2" value={input} onChange={e => setInput(e.target.value)} placeholder="Digite o texto" />
      <button className="mt-2 px-3 py-1 bg-green-600 text-white rounded" onClick={run}>Executar</button>
      <pre className="mt-4 bg-gray-100 p-2 rounded min-h-[120px] whitespace-pre-wrap">{output}</pre>
    </div>
  );
}
