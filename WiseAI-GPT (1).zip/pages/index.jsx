
import React, { useState } from 'react';
import AgentEditor from '../components/AgentEditor';
import Playground from '../components/Playground';

export default function Home() {
  const [agent, setAgent] = useState(null);

  return (
    <div className="min-h-screen p-6 bg-gray-50">
      <h1 className="text-2xl font-bold mb-4">Wise AI GPT - Editor Visual</h1>
      <div className="grid grid-cols-2 gap-6">
        <AgentEditor onSave={setAgent} />
        <Playground agent={agent} />
      </div>
    </div>
  );
}
