
import fetch from 'node-fetch';
import { AGENTS } from './agents';

export default async function handler(req, res) {
  const { agentId, input } = req.query;
  const agent = AGENTS.find(a => a.id === agentId);
  if (!agent) return res.status(404).json({ error: 'agent not found' });

  const modelNode = agent.nodes.find(n => n.type === 'model');
  const prompt = (modelNode.promptTemplate || '{{user_input}}').replace('{{user_input}}', input);

  res.setHeader('Content-Type','text/event-stream');
  res.setHeader('Cache-Control','no-cache');
  res.setHeader('Connection','keep-alive');

  const resp = await fetch(`${process.env.OPENAI_API_BASE}/chat/completions`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: modelNode.model || 'gpt-4-turbo',
      messages: [{ role: 'user', content: prompt }],
      stream: true,
      temperature: modelNode.temperature ?? 0.2
    })
  });

  const reader = resp.body.getReader();
  const decoder = new TextDecoder();

  while(true){
    const { done, value } = await reader.read();
    if(done) break;
    const text = decoder.decode(value);
    res.write(`data: ${JSON.stringify({type:'token', token:text})}\n\n`);
  }

  res.write(`data: ${JSON.stringify({type:'done'})}\n\n`);
  res.end();
}
