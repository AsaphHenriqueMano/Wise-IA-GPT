
let AGENTS = [];
export default function handler(req, res) {
  if (req.method === 'GET') return res.status(200).json(AGENTS);
  if (req.method === 'POST') {
    const body = req.body;
    const idx = AGENTS.findIndex(a => a.id === body.id);
    if (idx >= 0) AGENTS[idx] = body; else AGENTS.push(body);
    return res.status(200).json(body);
  }
  return res.status(405).end();
}
