
# Wise AI GPT

MVP de editor visual estilo GPT Maker usando Next.js, React Flow e OpenAI GPT-4-turbo.

## Deploy
1. Suba o projeto no GitHub ou envie o ZIP para Vercel.
2. Configure a variável de ambiente OPENAI_API_KEY (já incluída para testes locais).
3. Deploy e acesse o editor visual + playground.

⚠️ **Não compartilhe sua chave API publicamente!**
